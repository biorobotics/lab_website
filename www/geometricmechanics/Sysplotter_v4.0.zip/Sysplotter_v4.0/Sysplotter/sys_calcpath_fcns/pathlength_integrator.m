function dS = pathlength_integrator(t,y,metric,phi_fun,dphi_fun) %#ok<INUSL>

	% Get the shape and shape derivative at the current time
	shape = phi_fun(t);
	shapelist = num2cell(shape);
	dshape = dphi_fun(t);
	
	% Evaluate the metric tensor

	M = metric(shapelist{:});
	
	% get the contribution to the pathlength
	dS = sqrt(dshape(:)' * M * dshape(:));
	

	
end