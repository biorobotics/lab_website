function [path, fname, extension,version] = fileparts2(name)
%FILEPARTS2 Filename parts.
%   [PATHSTR,NAME,EXT] = FILEPARTS2(FILE) returns the path, 
%   filename and extension for the specified file. 
%   FILEPARTS2 is platform dependent.
%
%   You can reconstruct the file from the parts using
%      fullfile(pathstr,[name ext versn])
%   
%   The fourth output, VERSN, of FILEPARTS2 will be removed in a future
%   release.
%
%   See also FULLFILE, PATHSEP, FILESEP.

%   Copyright 1984-2007 The MathWorks, Inc.
%   $Revision: 1.18.4.9 $ $Date: 2009/11/16 22:26:43 $
%
%   Modified 2011 by Ross Hatton:
%   Fixed behavior for fname/extension return when fname is a directory
%   containing a . character

% Nothing but a row vector should be operated on.
if ~ischar(name) || size(name, 1) > 1
    error('MATLAB:fileparts:MustBeChar', 'Input must be a row vector of characters.');
end

path = '';
fname = '';
extension = '';
version = '';

if isempty(name)
    return;
end

builtinStr = xlate('built-in');
if strncmp(name, builtinStr, size(builtinStr,2))
    fname = builtinStr;
    return;
end

if ispc
    ind = find(name == '/'|name == '\', 1, 'last');
    if isempty(ind)
        ind = find(name == ':', 1, 'last');
        if ~isempty(ind)       
            path = name(1:ind);
        end
    else
        if ind == 2 && (name(1) == '\' || name(1) == '/')
            %special case for UNC server
            path =  name;
            ind = length(name);
        else 
            path = name(1:ind-1);
        end
    end
    if isempty(ind)       
        fname = name;
    else
        if ~isempty(path) && path(end)==':' && ...
                (length(path)>2 || (length(name) >=3 && name(3) == '\'))
                %don't append to D: like which is volume path on windows
            path = [path '\'];
        elseif isempty(deblank(path))
            path = '\';
        end
        fname = name(ind+1:end);
    end
else    % UNIX
    ind = find(name == '/', 1, 'last');
    if isempty(ind)
        fname = name;
    else
        path = name(1:ind-1); 

        % Do not forget to add filesep when in the root filesystem
        if isempty(deblank(path))
            path = '/';
        end
        fname = name(ind+1:end);
    end
end

if isempty(fname)
    return;
end

% Look for EXTENSION part

% Modifications by Ross Hatton: Only separate out the extension if fname
% points to a file. Dots are valid parts of directory names.

if ~isdir(fname)

	ind = find(fname == '.', 1, 'last');

	if isempty(ind)
		return;
	else
		extension = fname(ind:end);
		fname(ind:end) = [];
	end
	
else
	
	return
	
end
