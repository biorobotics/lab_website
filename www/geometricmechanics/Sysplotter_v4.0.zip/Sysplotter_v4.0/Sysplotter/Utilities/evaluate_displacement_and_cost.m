function [net_disp_orig, net_disp_opt, cost] = evaluate_displacement_and_cost(s,gait,tspan, method)
% Evaluate the displacement and cost for the gait specified in the
% structure GAIT when executed by the system described in the structure
% S.
%
% S should be a sysplotter 's' structure loaded from a file
% sysf_FILENAME_calc.mat (note the _calc suffix)
%
% GAIT should be a structure with fields "phi" and "dphi", returning a
% vector of shapes and shape velocities respectively. If it is not
% convenient to analytically describe the shape velocity function,
% gait.dphi should be defined as 
%
% gait.dphi =  @(t) jacobianest(@(T) gait.phi (T),t)
%
% METHOD can specify whether the local connection should be generated from
% its original function definiton, or by interpolation into the evaluated
% matrix, but is optional. Valid options are 'functional' or 'interpolated'
	

	% if no method is specified, default to functional
	if ~exist('method','var')
		method = 'functional';
	end

	% Calculate the system motion over the gait
	sol = ode45(@(t,y) helper_function(t,y,s,gait,method),tspan,[0 0 0 0]');
	
	% Extract the final motion
	disp_and_cost = deval(sol,tspan(end));
	
	net_disp_orig = disp_and_cost(1:3);
	cost = disp_and_cost(end);
	
	% Convert the final motion into its representation in optimal
	% coordinates
	startshape = gait.phi(0);
	startshapelist = num2cell(startshape);
	beta_theta = interpn(s.grid.eval{:},s.B_optimized.eval.Beta{3},startshapelist{:},'cubic');
	net_disp_opt = [cos(beta_theta) sin(beta_theta) 0;...
		-sin(beta_theta) cos(beta_theta) 0;...
		0 0 1]*net_disp_orig;
	
end


% Function to evaluate displacement and differential cost at each time
function dX = helper_function(t,X,s,gait,method)

	% X is the accrued displacement and cost

	% Get the shape and shape derivative at the current time
	shape = gait.phi(t);
	shapelist = num2cell(shape);
	dshape = gait.dphi(t);
	
	
	% Get the local connection at the current time, in the new coordinates	
	switch method
		case 'functional'
			A= s.A_num(shapelist{:})./s.A_den(shapelist{:});
		case 'interpolated'
			A = -cellfun(@(C) interpn(s.grid.eval{:},C,shapelist{:}),s.vecfield.eval.content.Avec);
		otherwise
			error('Unknown method for evaluating local connection');
	end
	
	% Get the body velocity at the current time
	xi = - A * dshape(:);
		
	% Rotate body velocity into world frame
	theta = X(3);
	v = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1]*xi;
	
	% Evaluate the metric tensor

	M = s.metric(shapelist{:});
	
	% get the contribution to the cost
	dcost = sqrt(dshape(:)' * M * dshape(:));
	
	% Combine the output
	dX = [v;dcost];
	

end