function [W] = generate_n_link_honey_swimmer_connection(N)

%drag coefficient ratio
syms k

%generate the link velocities
[xi_medial,xi_proximal,xi_distal,medial,proximal,distal,theta] = nlinkvelocities(N); %#ok<ASGLU>

%%%%%%%%%%%
% Separate out list of velocities

v = sym([]);

% Body velocity of system (taken at the first link)
xi = sym(zeros(3,1));
for i = 1:length(xi)
	v(end+1,1) = sym(['xi_' num2str(i)]);
end

% Joint angular velocities
alpha_dot = sym(zeros(N-1,1));
for i = 1:length(alpha_dot)
	v(end+1,1) = sym(['alpha_' num2str(i) '_dot']);
end

% Joint angles
alpha = sym(zeros(N-1,1));
for i = 1:length(alpha)
	alpha(i) = sym(['alpha_' num2str(i)]);
end

% half-Length of each link
L = sym(zeros(N,1));
for i = 1:length(L)
	L(i) = sym(['L_' num2str(i)]);
end

%%%%%
%iterate over link body velocities, each of which provides one external
%force vector
F_body = cell(size(xi_medial));
F = cell(size(xi_medial));
for i = 1:length(xi_medial)
    
    %Get the body frame external force and moment on the link, based on a
    %slender body approximation
            
    %get the body-frame drag force
    F_body{i} = xi_medial{i} .* ((-2*L(i)*k)*[1;2;(2/3)*L(i)^2]);
    
    %Rotate the body frame drag force into the instantaneous world frame
    F{i} = [cos(theta(i)) -sin(theta(i)) 0;
            sin(theta(i)) cos(theta(i))  0;
            0                 0          1] * F_body{i};
        
end

%Sum the external force vectors
F_ext = sum([F{:}],2);

%Add in the moments from the external forces
for i = 1:length(F)
    
    F_ext(3) = F_ext(3) - F{i}(1)*medial{i}(2,3) + F{i}(2)*medial{i}(1,3);
    
end


%Express force constraints as matrix W
W = sym(zeros(length(F_ext),length(v)));

%make each element of F_ext a constraint row
for i = 1:length(F_ext)
    
    %iterate over velocity components
    for j = 1:length(v)
        
        %zero out all but the jth  velocity component
        replacement_values = zeros(length(v),1);
        replacement_values(j) = 1;
        
        %place remaining coefficient into W matrix
        W(i,j) = subs(F_ext(i),v,replacement_values);
        
    end
    
end

%Local connection is first block of W left divided into second block

W = simple(W);
% A = simple(W(:,1:3)\W(:,4:5));
% 
% A_vectorized = cell(size(A));
% for i = 1:size(A,1)
%     
%     for j = 1:size(A,2)
%         
%         A_vectorized{i,j} = [vectorize(char(A(i,j))) '.*ones(size(alpha_1))'];
%         
%     end
%     
% end
% 
% A_honey_swimmer = A;
% W_honey_swimmer = W;
% A_vectorized_honey_swimmer = A_vectorized;

