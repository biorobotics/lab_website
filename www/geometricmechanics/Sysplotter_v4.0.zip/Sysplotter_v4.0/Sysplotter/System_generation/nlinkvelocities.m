function [xi_medial,xi_proximal,xi_distal,medial,proximal,distal,theta,...
	xi,L,alpha,alpha_dot] = nlinkvelocities(N)
% Get the body velocity of each link (at its center) as a function of the body velocity of
% the center of the chain, the lengths of the links, the joint angles between the
% links, and the joint velocities

	%%%%%
	%initialize the symbolic variables for the problem

	% Body velocity of system (taken at the first link)
	xi = sym(zeros(3,1));
	for i = 1:length(xi)
		xi(i) = sym(['xi_' num2str(i)]);
	end

	% half-Length of each link
	L = sym(zeros(N,1));
	for i = 1:length(L)
		L(i) = sym(['L_' num2str(i)]);
	end

	% Joint angles
	alpha = sym(zeros(N-1,1));
	for i = 1:length(alpha)
		alpha(i) = sym(['alpha_' num2str(i)]);
	end
	
	% Joint angular velocities
	alpha_dot = sym(zeros(N-1,1));
	for i = 1:length(alpha_dot)
		alpha_dot(i) = sym(['alpha_' num2str(i) '_dot']);
	end
	

	%%%%%%%%%%%
	% Build up the end and midlink positions of the joints
	
	% Prime arrays to hold the homogeneous representations of the positions
	proximal = cell(N,1);
	medial = cell(N,1);
	distal = cell(N,1);
	theta = sym(zeros(N,1));
	
	% Handle things slightly differently if N is odd or even
	
	% Algorithm for odd number of links
	if floor(N/2) ~= N/2
	
		% Insert values for the middle link as a starting point
		
		mI = ceil(N/2); % Index of the middle link
		
		proximal{mI} = se2matrix(-L(1),0,0); % Proximal end of first link is at x=-L in first link body frame
		medial{mI} = sym(se2matrix(0,0,0));         % Working in the midpoint frame of the first link
		distal{mI} = se2matrix(L(1),0,0);	  % Distal end of first link is at x = L
		theta(mI) = 0; % keeping track of theta separately

		% Kinematically chain through the links
		for i = (mI-1):-1:1

			distal{i} = proximal{i+1} * se2matrix(0,0,-alpha(i)); % proximal end is at same location as previous distal, but rotated by the joint angle
			medial{i} = distal{i} * se2matrix(-L(i),0,0);          % midpoint is half a linklength down the link
			proximal{i} = distal{i} * se2matrix(-2*L(i),0,0);            % endpoint is one linklength away

			theta(i) = theta(i+1)-alpha(i); % Keep track of thetas, to avoid having to back them out of the rotation matrix

		end
		
		for i = (mI+1):N

			proximal{i} = distal{i-1} * se2matrix(0,0,alpha(i-1)); % proximal end is at same location as previous distal, but rotated by the joint angle
			medial{i} = proximal{i} * se2matrix(L(i),0,0);          % midpoint is half a linklength down the link
			distal{i} = proximal{i} * se2matrix(2*L(i),0,0);            % endpoint is one linklength away

			theta(i) = theta(i-1)+alpha(i-1); % Keep track of thetas, to avoid having to back them out of the rotation matrix

		end
		
		
	% Algorithm for even number of links	
	else
		
		% Insert values for the middle joint as starting point
		
		mI = N/2; % Index of the link proximal to the middle joint
		
		distal{mI} = se2matrix(0,0,-alpha(mI)/2);
		medial{mI} = distal{mI} * se2matrix(-L(mI),0,0);
		proximal{mI} = distal{mI} * se2matrix(-2*L(mI),0,0);
		theta{mI} = -alpha(mI)/2;
		
		proximal{mI+1} = se2matrix(0,0,alpha(mI)/2);
		medial{mI+1} = proximal{mI+1} * se2matrix(L(mI+1),0,0);
		distal{mI+1} = proximal{mI+1} * se2matrix(2*L(mI+1),0,0);
		theta{mI+1} = alpha(mI)/2;

		% Kinematically chain through the links
		for i = (mI-1):-1:1

			distal{i} = proximal{i+1} * se2matrix(0,0,-alpha(i)); % proximal end is at same location as previous distal, but rotated by the joint angle
			medial{i} = distal{i} * se2matrix(-L(i),0,0);          % midpoint is half a linklength down the link
			proximal{i} = distal{i} * se2matrix(-2*L(i),0,0);            % endpoint is one linklength away

			theta(i) = theta(i+1)-alpha(i); % Keep track of thetas, to avoid having to back them out of the rotation matrix

		end
		
		for i = (mI+2):N

			proximal{i} = distal{i-1} * se2matrix(0,0,alpha(i-1)); % proximal end is at same location as previous distal, but rotated by the joint angle
			medial{i} = proximal{i} * se2matrix(L(i),0,0);          % midpoint is half a linklength down the link
			distal{i} = proximal{i} * se2matrix(2*L(i),0,0);            % endpoint is one linklength away

			theta(i) = theta(i-1)+alpha(i-1); % Keep track of thetas, to avoid having to back them out of the rotation matrix

		end
		
	end
	
	%%%%%%%
	% Simplify the expressions
	for i = 1:N
		proximal{i} = simplify(proximal{i});
		medial{i} = simplify(medial{i});	
		distal{i} = simplify(distal{i});
	end
		
	%%%%%%%%%%
	% Build up the velocities at each position.
	%
	% For a known body velocity
	% at some point on a rigid body, the body velocity at another point is
	% found by making a double-adjoint transformation.
	%
	% Across joints, we make a coordinate rotation (negative to the joint
	% angle) and then simply add the 
	% joint velocities
	
	% Prime arrays to hold the homogeneous representations of the positions
	xi_proximal = cell(N,1);
	xi_medial = cell(N,1);
	xi_distal = cell(N,1);

	% Handle things slightly differently if N is odd or even
	
	% Algorithm for odd number of links
	if floor(N/2) ~= N/2
	
		% Insert values for the middle link as a starting point
		
		mI = ceil(N/2); % Index of the middle link
				
		% First link values
		xi_proximal{mI} = AdjointInverse(proximal{mI},theta(mI)) * Adjoint(medial{mI},theta(mI))*xi;
		xi_medial{mI} = xi;
		xi_distal{mI} = AdjointInverse(distal{mI},theta(mI)) * Adjoint(medial{mI},theta(mI))*xi;
	
		% Fill in values for other links
		for i = (mI-1):-1:1

			xi_distal{i} = RotationMatrix(alpha(i)) * xi_proximal(i+1) + [0;0;-alpha_dot(i)];
			xi_medial{i} = AdjointInverse(medial{i},theta(i)) * Adjoint(distal{i},theta(i)) * xi_distal{i};
			xi_proximal{i} = AdjointInverse(proximal{i},theta(i)) * Adjoint(distal{i},theta(i)) * xi_distal{i};

		end
		
		for i = (mI+1):N

			xi_proximal{i} = RotationMatrix(-alpha(i-1)) * xi_distal(i-1) + [0;0;alpha_dot(i-1)];
			xi_medial{i} = AdjointInverse(medial{i},theta(i)) * Adjoint(proximal{i},theta(i)) * xi_proximal{i};
			xi_distal{i} = AdjointInverse(distal{i},theta(i)) * Adjoint(proximal{i},theta(i)) * xi_proximal{i};

		end
		
	% Handling for even number, with xi the middle-joint velocity
	else
		
		mI = N/2; % Index of the proximal-to-middle link
				
		% velocity of link proximal to midjoint
		xi_distal{mI} = RotationMatrix(alpha(mI)/2)*xi + [0;0;-alpha_dot(mI)/2];
		xi_medial{mI} = AdjointInverse(medial{mI},theta(mI)) * Adjoint(distal{mI},theta(mI))*xi_distal{mI};
		xi_proximal{mI} = AdjointInverse(proximal{mI},theta(mI)) * Adjoint(distal{mI},theta(mI))*xi_distal{mI};

		% velocity of link distal to midjoint
		xi_proximal{mI+1} = RotationMatrix(-alpha(mI)/2)*xi + [0;0; alpha_dot(mI)/2];
		xi_medial{mI+1} = AdjointInverse(medial{mI+1},theta(mI+1)) * Adjoint(proximal{mI+1},theta(mI+1))*xi_proximal{mI+1};
		xi_distal{mI+1} = AdjointInverse(distal{mI+1},theta(mI+1)) * Adjoint(proximal{mI+1},theta(mI+1))*xi_proximal{mI+1};

		% Fill in values for other links
		for i = (mI-1):-1:1

			xi_distal{i} = RotationMatrix(alpha(i)) * xi_proximal(i+1) + [0;0;-alpha_dot(i)];
			xi_medial{i} = AdjointInverse(medial{i},theta(i)) * Adjoint(distal{i},theta(i)) * xi_distal{i};
			xi_proximal{i} = AdjointInverse(proximal{i},theta(i)) * Adjoint(distal{i},theta(i)) * xi_distal{i};

		end
		
		for i = (mI+2):N

			xi_proximal{i} = RotationMatrix(-alpha(i-1)) * xi_distal(i-1) + [0;0;alpha_dot(i-1)];
			xi_medial{i} = AdjointInverse(medial{i},theta(i)) * Adjoint(proximal{i},theta(i)) * xi_proximal{i};
			xi_distal{i} = AdjointInverse(distal{i},theta(i)) * Adjoint(proximal{i},theta(i)) * xi_proximal{i};

		end	
		
	end
	
	%%%%%%%
	% Simplify the expressions
	for i = 1:N
		xi_proximal{i} = simplify(xi_proximal{i});
		xi_medial{i} = simplify(xi_medial{i});	
		xi_distal{i} = simplify(xi_distal{i});
	end
	
end
	


function SE2 = se2matrix(x,y,theta)
% Convert from triple to homogeneous representation
	
	SE2 = [cos(theta) -sin(theta) x;
           sin(theta) cos(theta)  y;
           0           0          1];

end

function Adg = Adjoint(SE2,theta)
%fill in the adjoint matrix

	x = SE2(1,3);
	y = SE2(2,3);

    Adg = [cos(theta) -sin(theta) y;
           sin(theta) cos(theta) -x;
           0           0          1];
       
end

function Adg_inv = AdjointInverse(SE2,theta)
%fill in the adjoint inverse matrix

	x = SE2(1,3);
	y = SE2(2,3);
	
	Adg_inv = [cos(theta) sin(theta)  x*sin(theta)-y*cos(theta);
               -sin(theta) cos(theta) x*cos(theta)+y*sin(theta);
               0            0           1];
           
end

function R = RotationMatrix(theta)

    R = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
    
end

