function kappa = polynomial_1(s)
%First-order polynomial basis function for continuous curvature model

kappa = -s;