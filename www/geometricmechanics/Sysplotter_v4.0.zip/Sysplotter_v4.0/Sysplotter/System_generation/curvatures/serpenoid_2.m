function kappa = serpenoid_2(s)
%sinusoidal curvature

%kappa = cos(pi*(s+1));

kappa = -sin(pi*s);