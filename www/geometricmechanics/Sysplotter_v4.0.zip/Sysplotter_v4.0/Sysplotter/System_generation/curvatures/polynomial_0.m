function kappa = polynomial_0(s)
%Zeroth-order polynomial basis function for continuous curvature model

kappa = ones(size(s));