function kappa = serpenoid_1(s)
%sinusoidal curvature

%kappa = sin(pi*(s+1));

kappa = -cos(2*pi*(s+0.5));