function calc_honey_swimmer_power_field
% Get the power field for the honey swimmer

	% Get the link body velocities in terms of the joint velocities
	link_vels = find_link_body_velocities;
	
	% Get the body  drag forces on the link in terms of the joint velocities
	drag_forces = find_body_drag(link_vels);
	
	% Get the moments on the joints from the drag forces
	joint_moments = find_joint_moments(drag_forces);
	
	% Build the power metric matrix and send it to an m-file
	build_power_metric(joint_moments);

end

function xi_full = find_link_body_velocities

	syms alpha_1_dot alpha_2_dot

	%First, get the local connection
	load('honey_swimmer_connection','A_honey_swimmer')
	
	%Second, get the three-link body velocities in terms of the generalized
	%velocities
	[xi_full] = threelinkvelocities('middle link');
	
	%Replace the system body velocity terms in xi_full with their functions
	%from the local connection
	for i = 1:length(xi_full)
		
		xi_full{i} = subs(xi_full{i}, {'xi_1','xi_2','xi_3'},...
			{-A_honey_swimmer(1,:)*[alpha_1_dot; alpha_2_dot],...
			-A_honey_swimmer(2,:)*[alpha_1_dot; alpha_2_dot],...
			-A_honey_swimmer(3,:)*[alpha_1_dot; alpha_2_dot]}); %#ok<NODEF>
		
	end	

end

function drag_forces = find_body_drag(link_vels)

	% Simple resistive force model
	
	syms L k
	
	% Drag coefficients
	Cr = [1*L*k; 2*L*k; (2/3)*(L^3)*k]*2; %*2 is to make k drag/unit length
	
	% Drag forces
	drag_forces = link_vels;
	for i = 1:length(link_vels)
		
		drag_forces{i} = Cr.*link_vels{i};
		
	end
	
end

function joint_moments = find_joint_moments(drag_forces)
	
	% Moment on each joint is from the rotational and lateral movement of
	% each link

	syms L

	joint_moments(1,1) = [L -1] * drag_forces{1}(2:3);
	
	joint_moments(2,1) = [L 1] * drag_forces{3}(2:3);
	
end

function build_power_metric(joint_moments)
	
	M = matrix_factor(joint_moments,{'alpha_1_dot'; 'alpha_2_dot'},'linear');
	
	%Set the length and drag coefficients to 1
	M = subs(M,{'L','R','k'},{1,1,1});
	
% 	%Set the off-diagonal terms to their negatives
% 	M(1,2) = -M(1,2);
% 	M(2,1) = -M(2,1);
	
	G = matlabFunction(M,'file','honey_power_metric');
	
end