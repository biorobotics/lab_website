function sys_draw_dummy_callback(hObject, eventdata, plot_structure,sys,shch)
%strip out extra callback info

	handles = guidata(hObject);

    sys_draw(plot_structure,sys,shch,handles.progresspanel,0,handles);

end