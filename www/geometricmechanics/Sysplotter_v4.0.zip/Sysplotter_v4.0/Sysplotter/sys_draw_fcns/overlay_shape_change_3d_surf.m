function overlay_shape_change_3d_surf(ax,p,zdata,convert)
%overlay shape changes onto the specified axis

	%plot all paths
	for i = 1:numel(p.phi_locus)

		%plot all segments of paths
		for j = 1:numel(p.phi_locus{i})

			if exist('convert','var') && ~isempty(convert)

			% Get the value by which to scale the height function
			ascale = arrayfun(@(x,y) 1/det(convert.jacobian(x,y)),p.phi_locus{i}{j}.shape(:,1), p.phi_locus{i}{j}.shape(:,2));

			% Apply the jacobian to the vectors
			zdata{i}{j} = ascale.*zdata{i}{j};

			[p.phi_locus{i}{j}.shape(:,1), p.phi_locus{i}{j}.shape(:,2)] ...
					= convert.old_to_new_points(p.phi_locus{i}{j}.shape(:,1), p.phi_locus{i}{j}.shape(:,2));
				
				

			end


			%draw the path itself
			line(p.phi_locus{i}{j}.shape(:,1),p.phi_locus{i}{j}.shape(:,2),zdata{i}{j},'Color','k','LineWidth',2.5,'Parent',ax);



		end


	end
    
end